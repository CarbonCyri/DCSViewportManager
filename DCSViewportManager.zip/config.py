# Config Variables

first_run = True
dcs_Path = r'C:/Program Files/Eagle Dynamics/DCS World/'
savedgames_Path = r'C:/User/NAME/Saved Games/DCS/'

# Viewport
viewport_airframe = []

# Kneeboard
kneeboard_enabled_airframes = []
kneeboard_size = {'x': 000, 'y': 000, 'width': 600, 'height': 800}
